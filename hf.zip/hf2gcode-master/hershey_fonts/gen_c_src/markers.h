/* This file was generated with gen_C_code.m from fixed/markers.jhf */

/* number of glyphs in font */
unsigned char markers_cnt = 97;

/* Format: margin left, margin right, X, Y ... \0
< R> is pen-up, see original hershey font */
const char markers [] PROGMEM="JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "KYQKNLLNKQKSLVNXQYSYVXXVYSYQXNVLSKQK\0"\
          "LXLLLXXXXLLL\0"\
          "KYRJKVYVRJ\0"\
          "LXRHLRR\\XRRH\0"\
          "JZRIPOJOOSMYRUWYUSZOTORI\0"\
          "LXPLPPLPLTPTPXTXTTXTXPTPTLPL\0"\
          "KYRKRY RKRYR\0"\
          "MWMMWW RWMMW\0"\
          "MWRLRX RMOWU RWOMU\0"\
          "NVQNOONQNSOUQVSVUUVSVQUOSNQN ROQOS RPPPT RQOQU RRORU RSOSU RTPTT RUQUS\0"\
          "NVNNNVVVVNNN ROOOU RPOPU RQOQU RRORU RSOSU RTOTU RUOUU\0"\
          "MWRLMUWURL RROOT RROUT RRRQT RRRST\0"\
          "LULRUWUMLR RORTU RORTO RRRTS RRRTQ\0"\
          "MWRXWOMORX RRUUP RRUOP RRRSP RRRQP\0"\
          "OXXROMOWXR RURPO RURPU RRRPQ RRRPS\0"\
          "D`DR`R RDRRb R`RRb\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "KYQKNLLNKQKSLVNXQYSYVXXVYSYQXNVLSKQK\0"\
          "LXLLLXXXXLLL\0"\
          "KYRJKVYVRJ\0"\
          "LXRHLRR\\XRRH\0"\
          "JZRIPOJOOSMYRUWYUSZOTORI\0"\
          "LXPLPPLPLTPTPXTXTTXTXPTPTLPL\0"\
          "KYRKRY RKRYR\0"\
          "MWMMWW RWMMW\0"\
          "MWRLRX RMOWU RWOMU\0"\
          "NVQNOONQNSOUQVSVUUVSVQUOSNQN ROQOS RPPPT RQOQU RRORU RSOSU RTPTT RUQUS\0"\
          "NVNNNVVVVNNN ROOOU RPOPU RQOQU RRORU RSOSU RTOTU RUOUU\0"\
          "MWRLMUWURL RROOT RROUT RRRQT RRRST\0"\
          "LULRUWUMLR RORTU RORTO RRRTS RRRTQ\0"\
          "MWRXWOMORX RRUUP RRUOP RRRSP RRRQP\0"\
          "OXXROMOWXR RURPO RURPU RRRPQ RRRPS\0"\
          "D`DR`R RDRRb R`RRb\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
          "JZ\0"\
;
/* End of file gen_c_src/markers.h */
